HÄR FINNS ALL INFO SOM SKA VARA I DOTENV OCH GITIGNORE FILERNA. 


Dotenv 

{
STORAGE_BUCKET=gs://hamsterwarsiths.appspot.com/
DB_URL=https://hamsterwarsiths.firebaseio.com
SERVICE_ACC=./fbadminkey.json
API_KEY=AIzaSyAHFQEHkjdigK1SGrYLAxpKNiEG4j9pmKs
}

GITIGNORE 

{
/keys-etc
.env
/fbadminkey.json
/node_modules
}
